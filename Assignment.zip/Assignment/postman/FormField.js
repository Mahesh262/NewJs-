import React from 'react';
import { Row, Nav, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { TiEdit, TiEye, TiDocumentDelete } from 'react-icons/ti';
import axios from 'axios';
const FormField = () => {
    const [data, setData] = React.useState({
        firstname: '',
        lastname: '',
        email: '',
    })
    // const { firstname, lastname, email } = data

    const changeHandlers = e => {
        setData({ ...data, [e.target.name]: e.target.value });
    }
    const [status, setStatus] = React.useState();
    const Submiter = async (e) => {
        e.preventDefault();
        console.log(data)
        try {
            await axios.post(`https://reqres.in/api/unknown/2`, data)

            setStatus(true);
            setStatus(data)
        }
        catch (error) {
            console.log("something is wrong");

        }

    }
    if (status) {
        return <FormField />
    }

    return <>
        <div className='row'>

            <h2 style={{ textAlign: "center" }}>Registration</h2>
            <form className='form-horizontal' autoComplete='off' onSubmit={Submiter}>
                <div className='form-group'>
                    <label className='control-label col-sm-2'>First Name</label>
                    <div className='Control-sm-4'>
                        <input type="text"
                            className='form-control' placeholder="firstName" name="firstname"
                            onChange={changeHandlers} />
                    </div>
                </div>
                <div className='form-group'>
                    <label className='control-label col-sm-2'>Last Name</label>
                    <div className='Control-sm-4'>
                        <input type="text"
                            className='form-control' placeholder="Last Name" name="lastname"
                            onChange={changeHandlers} />
                    </div>
                </div>
                <div className='form-group'>
                    <label className='control-label col-sm-2'>EMail</label>
                    <div className='Control-sm-4'>
                        <input type="email"
                            className='form-control' placeholder="EmaildAadres" name="email"
                            onChange={changeHandlers} />
                    </div>
                </div>
                <div className='form-group'>
                    <div className='Control-sm-4'>
                        <input type="Submit"
                            className='form-control btn btn-success' name="submit" />
                    </div>
                </div>
            </form>
        </div>
        <Row>
            <h1>Student List </h1>
            <Nav className='nav bg-dark ' fill variant='tabs'>
                <Nav.Link href="#home">N0</Nav.Link>
                <Nav.Link href="#home">StudentName</Nav.Link>
                <Nav.Link href="#features">Rol</Nav.Link>
                <Nav.Link href="#pricing">Batch</Nav.Link>
            </Nav>

            <Row style={{ display: "flex", flexDirection: 'flexEnd' }}>
                <Col><Link to="/">Name</Link>
                </Col>

                <Col><Link to="/Bcompnt"> <TiDocumentDelete /></Link></Col>
                <Col><TiEye /></Col>
                <Col><TiEdit /></Col>

            </Row>
        </Row>

    </>;
};
export default FormField