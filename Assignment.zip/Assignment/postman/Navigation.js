import React from 'react'
import './Topsec.css'

import { Nav, DropdownButton, Dropdown, ButtonGroup } from 'react-bootstrap'
import { AiOutlineSearch, AiFillCloud } from 'react-icons/ai'
import { BsFillPersonPlusFill } from 'react-icons/bs'
import { MdRssFeed } from 'react-icons/md'
import { FiSettings } from 'react-icons/fi'
import { BsBell } from 'react-icons/bs'
import { GiRamProfile } from 'react-icons/gi'


const Navigation = () => {
    return (
        <>
            <div bg="success" className="navbar navbar-expand-sm">
                <Nav.Link href="#">Home</Nav.Link>
                <Nav.Link href="#">
                    {[DropdownButton].map((DropdownType, idx) => (
                        <DropdownType
                            as={ButtonGroup}
                            key={idx}
                            id={`dropdown-button-drop-${idx}`}
                            size="sm"
                            variant="light"
                            title="Workspace"
                        >
                            <Dropdown.Item eventKey="1">Action</Dropdown.Item>
                            <Dropdown.Item eventKey="2">Another action</Dropdown.Item>
                            <Dropdown.Item eventKey="3">Something else here</Dropdown.Item>
                            <Dropdown.Divider />
                            <Dropdown.Item eventKey="4">Separated link</Dropdown.Item>
                        </DropdownType>
                    ))}



                </Nav.Link>
                <Nav.Link href="#">
                    {[DropdownButton].map((DropdownType, idx) => (
                        <DropdownType
                            as={ButtonGroup}
                            key={idx}
                            id={`dropdown-button-drop-${idx}`}
                            size="sm"
                            variant="light"
                            title="API Network"
                        >
                            <Dropdown.Item eventKey="1">Action</Dropdown.Item>
                            <Dropdown.Item eventKey="2">Another action</Dropdown.Item>
                            <Dropdown.Item eventKey="3">Something else here</Dropdown.Item>
                            <Dropdown.Divider />
                            <Dropdown.Item eventKey="4">Separated link</Dropdown.Item>
                        </DropdownType>
                    ))}

                </Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}>Reports</Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}>Explore</Nav.Link>
                <strong><AiOutlineSearch /></strong>
                <Nav.Link href="#" style={{ color: 'black' }}> <form> <input type="text" placeholder='searchPostman' /> </form></Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}><strong><AiFillCloud /></strong></Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}><strong><BsFillPersonPlusFill /></strong></Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}><strong><MdRssFeed /></strong></Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}><strong>< FiSettings /></strong></Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}><strong><  BsBell /></strong></Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}><strong>< GiRamProfile /></strong></Nav.Link>
                <Nav.Link href="#" style={{ color: 'black' }}> Upgrade</Nav.Link>
            </div>

        </>

    )
}

export default Navigation