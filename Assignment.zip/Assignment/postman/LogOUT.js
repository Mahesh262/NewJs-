import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap'
import axios from 'axios'

const LogOUT = () => {
    const [custmr, setCustmr] = useState([])

    useEffect(() => {
        Fetchroducts();
    }, [])
    const Fetchroducts = () => {
        axios.get('https://jsonplaceholder.typicode.com/posts').then((res) => {

            setCustmr(res.data)
        }).catch((error) => {
            console.log(error)
        });
    }

    return (
        <><Button variant="dark">LogOut</Button>
            {custmr.map((custmr) => {
                return <div key={custmr.id}>{custmr.title} &nbsp;
                </div>


            })}
        </>
    )
}

export default LogOUT