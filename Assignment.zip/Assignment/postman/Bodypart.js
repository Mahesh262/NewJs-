import React, { useRef } from 'react'
import { Row, Col, Nav, Form, Button } from 'react-bootstrap'
import axios from 'axios'

const Bodypart = () => {
    // const [selects, setSelects] = useState()
    let scv = useRef()
    let URI = useRef('')
    const resposebody = useRef(
        {
            name: 'Antarica',
            value: "231",
        }
    )



    const cmpld = e => {
        e.preventDefault();


        const produtcs = (scv, URI, resposebody = {}) => {
            switch (scv) {
                case 'get':
                    console.log(axios.get(URI).then(res => console.log(res.data)).catch(error => console.log(error)))
                    break;
                case 'post':
                    console.log(axios.post(URI, resposebody).then(res => console.log(res.data)).catch(error => console.log(error)))

                    break;
                default:
                    console.log('helosd')
            }

        }
        produtcs(scv, URI, resposebody)
        console.log(scv)

    }

    return (
        <>
            <Row className='row w-100'>
                <Col xs={6} sm={4} overflow="hidden">
                    <div className="navbar navbar-expand-sm-lg navbar-inverse">
                        <ol className='navbar navbar-nav'>
                            <li className='nav-item'>My work space</li>
                        </ol>

                    </div>

                </Col>
                <Col xs={12} sm={8}>
                    <Nav.Link>homee</Nav.Link>
                    <Form onSubmit={cmpld}>
                        <Col>
                            <Form.Select style={{ width: "100px" }} onChange={e => scv = e.target.value}>
                                <option>None</option>
                                <option value='post'>post</option>
                                <option value='get'>get</option>

                            </Form.Select>
                            <Form.Control type="text" placeholder="search" onChange={e => URI = e.target.value} />
                            <Button variant="primary" type="submit">Send</Button>
                        </Col>
                    </Form>
                </Col>
            </Row>
        </>
    )
}

export default Bodypart