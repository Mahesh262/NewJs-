import React from 'react'

const Acpnt = ({ state }) => {
    return (
        <>  counter {state.counter}</>
    )
}

export default Acpnt