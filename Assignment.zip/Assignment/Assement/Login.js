import React from 'react'
// import axios from 'axios';
// import { Link } from 'react-router-dom';s
import { GoogleLogin } from 'react-google-login';

const Login = () => {
    const [username, setUsername] = React.useState('')
    const [title, setTitle] = React.useState('')


    const responsivegoogle = (res) => {
        console.log(res)
    }
    const confirm = (e) => {
        e.preventDefault();
        let dataa = { username, title }
        fetch('https://reqres.in/api/users?page=1', {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dataa)
        }).then((res) => {
            res.json().then((result) => {
                console.log(result)
            })
        })
        console.log(dataa)
    }
    // useEffect(() => {


    // }, [formdata])
    // useEffect(() => {    
    //     Fetchroducts();
    // }, [])
    // const Fetchroducts = () => {
    //     axios.get('https://jsonplaceholder.typicode.com/posts').then((res) => {

    //         setFormdata(res.data)
    //     }).catch((error) => {
    //         console.log(error)
    //     });
    // }

    return (
        <>
            <center className="App">


                <form onSubmit={confirm} autoComplete="off">
                    <label>UserName</label>
                    <input
                        onChange={(e) => setUsername(e.target.value)}
                        type="text"
                        name="username"
                        className='form-control w-50'
                        value={username}
                        placeholder="text"

                    />
                    <label>Mail</label>

                    <input
                        onChange={(e) => setTitle(e.target.value)}
                        type="text"
                        name="title"
                        className='form-control w-50'
                        value={title}
                        placeholder="text"


                    />

                    <input
                        type="submit"
                        value="Login"
                        className='form-control w-50'

                    />
                </form>
                <GoogleLogin
                    clientId="693006210236-kua4k7d04ndk5952902gvdn29225ghcf.apps.googleusercontent.com"
                    buttonText="Sign In"
                    onSuccess={responsivegoogle}
                    onFailure={responsivegoogle}
                />
                {/* {formdata.map((formdata)=>{
                    return <div key= {formdata.id}>
                        {formdata.body}

                    </div>
                })} */}
            </center>
        </>
    )
}

export default Login