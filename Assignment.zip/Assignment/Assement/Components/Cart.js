import React from 'react';
import { Badge, Container, Row, Col, Button } from 'react-bootstrap';
import { useCart } from 'react-use-cart';

const Cart = () => {
    const {
        isEmpty,
        totalUniqueItems,
        items,
        totalItems,
        cartTotal,
        updateItemQuantity,
        removeItem, emptyCart,
    } = useCart();

    const addNewItemToMenu = (name, image, cost) => {
        name.push(name)
        console.log(image.push(image))
        cost.push(cost)
    }

    if (isEmpty) return <h1 className='text-center pt-3 me-auto'> cart is Empty</h1>
    return <>
        <Container className='pt-3 bg-success'>
            <Row>
                <Col className="col-12 pt-3">
                    <h5><Badge>Cart ({totalUniqueItems})</Badge></h5>
                    <h5><Badge>Total ({totalItems})</Badge></h5>
                    <Col>
                        {items.map((item, index) => {
                            return <Col key={index}>
                                <Row><img src={item.img} alt=".." style={{ width: "8em" }} /></Row>
                                <Row> <h3> Brand<br /><strong> {item.title}   </strong></h3></Row>
                                <Row>{item.price}</Row>
                                <Row>Quantity:{items.quantity}</Row>
                                <Button className='btn btn-primary' onClick={() => updateItemQuantity(item.id, item.quantity - 1)}>-</Button>
                                <Button className='btn btn-primary' onClick={() => updateItemQuantity(item.id, item.quantity + 1)}>+</Button>
                                <Button variant="danger" onClick={() => removeItem(item.id)}>Remove</Button>
                            </Col>
                        })}
                    </Col>
                </Col>
            </Row>
            <Row>
                <label for="productName">Enter Name of Items</label>
                <input name="productName" type="text" />

                <label for="productImage">Enter image URL of the Product</label>
                <input name="productImage" type="text" />

                <label for="productCost">Enter cost of the  Product</label>
                <input name="productCost" type="text" />

                <button onClick={addNewItemToMenu}>Add new Menu Item</button>
            </Row>
            <Col className='col-auto'>
                <h2>Cart Total ${cartTotal}</h2>
            </Col>
            <Col className='col-auto'>
                <Button variant="danger" onClick={() => emptyCart(items)}>Clear</Button>
            </Col>
        </Container>

    </>
};

export default Cart;
