import React from 'react';
import Prodducts from './Prodducts';
import Data from './Data';
import Naavi from './Naavi';


const Home = () => {
    return <>
        <Naavi />
        <div className="shopp" style={{ width: "100%" }} >
            <div className='nextone' style={{ display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center" }}>
                {Data.productsData.map((item, index) => {
                    return <Prodducts img={item.img}
                        title={item.title}
                        price={item.price}
                        item={item}
                        key={index} />

                })}




            </div>
        </div>

    </>;
};

export default Home;

