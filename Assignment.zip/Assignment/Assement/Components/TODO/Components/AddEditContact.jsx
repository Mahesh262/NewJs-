import React from 'react'
import { useState } from 'react'
import { Form, Button } from 'react-bootstrap'
import { connect } from 'react-redux'
import { addcontact } from '../Actions/ContactACTION'

const AddEditContact = ({ addcontact }) => {
    const [contacr, setContact] = useState({
        UserName: '',
        mail: '',
        number: ''

    })
    const handleChange = (UserName, value) => {
        const oldContact = { ...contacr }
        console.log(oldContact)
        oldContact[UserName] = value;
        setContact(oldContact)
    }

    return (
        <>
            <Form>
                <Form.Label>UserName</Form.Label>
                <input type="text" className='form-control' value={contacr.UserName} placeholder="Enter Name" onChange={(e) => handleChange('UserName', e.target.value)} />
                <Form.Label>Email address</Form.Label>
                <input type="email" className='form-control' value={contacr.mail} placeholder="Enter email" onChange={(e) => handleChange('mail', e.target.value)} />
                <Form.Label>Contact</Form.Label>
                <input type="number" className='form-control' value={contacr.number} placeholder="Contact" onChange={(e) => handleChange('phone', e.target.value)} />

            </Form>
            <Button variant="primary" type="button" onClick={addcontact(contacr)}>
                SBUMIT
            </Button>

        </>
    )
}
const mapStateToProps = (state) => {
    return {
        contacts: state.contacts

    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        addcontact: (contacr) => dispatch(addcontact(contacr))
    };
}


export default connect(mapStateToProps, mapDispatchToProps)(AddEditContact)

