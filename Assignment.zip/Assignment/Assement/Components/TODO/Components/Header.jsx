import React from 'react'
import { Nav, Navbar } from 'react-bootstrap'
const Header = () => {
    return (
        <>
            <Navbar className='bg-dark justify-content-center'>
                <Nav.Link><input
                    type='text' /></Nav.Link>
                <Nav.Link>Search</Nav.Link>
            </Navbar></>
    )
}

export default Header