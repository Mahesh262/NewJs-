/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect } from 'react'
import { Modal, Button, Nav, Col, Row, Badge, Container } from 'react-bootstrap'
import { AiOutlineDelete } from 'react-icons/ai'
import { FiEdit } from 'react-icons/fi'
import { connect } from 'react-redux'
import { getallContacts } from '../Actions/ContactACTION'
import AddEditContact from './AddEditContact'

const Hcontact = ({ getallContacts, contacts }) => {
  const [show, setShow] = React.useState(false);

  const handleShow = () => setShow(true);


  useEffect(() => {
    getallContacts()
  }, [])

  return (
    <>

      <Nav style={{ display: 'flex', justifyContent: 'flex-end' }}><Button> <Badge>+</Badge>Addcontact</Button></Nav>
      <Container>

        <Nav className='bg-dark text-light' style={{ display: 'flex', justifyContent: 'center', textTransform: 'uppercase' }}>
          <Col>S.No</Col>
          <Col> Name</Col>
          <Col>Mobile</Col>
          <Col>mail</Col>
          <Nav>
            <Col>Actions</Col>
          </Nav>
        </Nav>

        {contacts.length > 0 && contacts.map((contacts, index) => (
          <Row key={contacts.id} >
            <Col>{index + 1}</Col>
            <Col>{contacts.name}</Col>
            <Col>{contacts.phone}</Col>
            <Col></Col>
            <Col>{contacts.mail}</Col>
            <Col><button className='btn btn-primary'>

              <FiEdit onClick={handleShow} />
            </button></Col>
            <Col><button className='btn btn-warning'> <AiOutlineDelete /></button></Col>
          </Row>
        ))}

        <Modal>
          <A
        </Modal>

      </Container>

    </>
  )
}
const mapStateToProps = (state) => {
  return {
    contacts: state.contacts
  }

}
const mapDispatchToProps = (dispatch) => {
  return {
    getallContacts: () => dispatch(getallContacts())

  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Hcontact)