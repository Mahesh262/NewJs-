export const getallContacts = () => {
    return { type: "GET_ALL_CONTACT", }
}
export const addcontact = (contacts) => {
    return { type: 'ADD_CONTACT', playload: contacts }
}