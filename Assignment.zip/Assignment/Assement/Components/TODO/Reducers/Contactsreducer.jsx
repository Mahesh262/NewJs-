const intitialContact = {
    contacts: [{
        id: 1,
        name: 'mahs',
        phone: '912221',
        mail: 'mahesh@gmas.com'
    }],
}
export const CONTACTREDUCER = (state = intitialContact, action) => {
    switch (action.type) {
        case 'GET_ALL_CONTACT':
            return { ...state }
        case 'ADD_CONTACT': {
            let contacts = [...state.contacts];
            contacts.push(action.payload)
            return { ...state, contacts }
        }
        default:
            return state
    }
}