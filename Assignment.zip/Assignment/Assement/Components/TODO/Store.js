import { createStore } from "redux";
import { CONTACTREDUCER } from './Reducers/Contactsreducer'
const store = createStore(CONTACTREDUCER);
export default store