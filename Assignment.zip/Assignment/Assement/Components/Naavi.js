import React, { useState } from 'react';
import { Button, Nav, NavDropdown, Offcanvas, Badge } from 'react-bootstrap';
import { AiOutlineShoppingCart } from "react-icons/ai"
import Cart from './Cart';
import { useCart } from 'react-use-cart';
import './naavi.css'
const Naavi = () => {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const { totalUniqueItems } = useCart()


    return <>
        <Nav fill variant='tabs' className='nav bg-success'>
            <Nav.Link className="text-light" id="navi" href="">Home</Nav.Link>
            <Nav.Link className="text-light" id="navi" href="">Services</Nav.Link>
            <Nav.Link className="text-light" id="navi" href="">About</Nav.Link>
            <Nav.Link className="text-light" id="navi" href="">Login</Nav.Link>
            <NavDropdown title="Homes" id="nav-dropdown">
                <NavDropdown.Item >Action</NavDropdown.Item>
                <NavDropdown.Item >Another</NavDropdown.Item>
                <NavDropdown.Item >Something</NavDropdown.Item>
                <NavDropdown.Item >separated</NavDropdown.Item>
            </NavDropdown>
            <Button variant="Success" className="recive" onClick={handleShow}>  <AiOutlineShoppingCart /><Badge className='bg-danger'> {totalUniqueItems} </Badge></Button>
            <Offcanvas show={show} onHide={handleClose}>
                <Offcanvas.Header closeButton>
                    <Offcanvas.Title>Offcanvaas</Offcanvas.Title>
                </Offcanvas.Header>
                <Offcanvas.Body>
                    <h2>Cart Section</h2>
                    <Cart />
                </Offcanvas.Body>
            </Offcanvas>
        </Nav>
    </>;
};

export default Naavi;
