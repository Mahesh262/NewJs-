import React from 'react';
import { Container, Col, Card, Button } from 'react-bootstrap';
import { useCart } from 'react-use-cart';
const Prodducts = (props) => {
    const { addItem } = useCart();
    return <>
        <Container className='container pt-3 bg-Success'>
            <Col style={{ border: "2px solid green" }}>
                <Card className="bg-warning justify-content-center" >
                    <img src={props.img} alt="Lo" className='card-img-top' />
                    <Card.Body>
                        <h4>{props.title}</h4>
                        <h3>${props.price}</h3>
                    </Card.Body>
                    <Card.Footer>
                        <Button variant="primary" onClick={() => addItem(props.item)}>Add cart</Button>
                    </Card.Footer>
                </Card>

            </Col>
        </Container>
    </ >;
};

export default Prodducts;
