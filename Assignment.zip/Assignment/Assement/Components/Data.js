const Data = {
    productsData: [
        {
            id: 1,
            img: "https://image.freepik.com/free-vector/realistic-vasant-panchami_52683-54087.jpg?w=900",
            title: "puff",
            price: 32,

        },
        {
            id: 2,
            img: "https://image.freepik.com/free-vector/vasant-panchami-celebration-background-vector-illustration_460848-8869.jpg?w=740",
            title: "art",
            price: 12,

        },
        {
            id: 3,
            img: "https://image.freepik.com/free-vector/watercolor-hot-pot-illustration_23-2148790828.jpg?w=900",
            title: "mangoes",
            price: 22,

        },
        {
            id: 4,
            img: "https://image.freepik.com/free-vector/watercolor-hot-pot-illustration_23-2148790828.jpg?w=900",
            title: "fruit",
            price: 22,

        },
        {
            id: 5,
            img: "https://image.freepik.com/free-vector/watercolor-hot-pot-illustration_23-2148790828.jpg?w=900",
            title: "orange",
            price: 33,

        },
    ]
}
export default Data