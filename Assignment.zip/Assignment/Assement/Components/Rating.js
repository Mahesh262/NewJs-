import React from 'react';

export const Rating = () => {
    return <div> Ratings 2A</div>;
};
