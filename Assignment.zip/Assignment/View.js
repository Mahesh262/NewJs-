import React from 'react'
import { Nav } from 'react-bootstrap'
import { useLocation, useNavigate } from 'react-router-dom'

const View = () => {
    const moving = useNavigate()
    const draw = () => {
        moving("/Counter")
    }
    const { search } = useLocation();
    return (
        <>
            <Nav>
                <Nav.Link onClick={draw}>Home</Nav.Link>
            </Nav>
        </>
    )
}

export default View